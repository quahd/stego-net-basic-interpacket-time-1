from scapy.all import sniff, ICMP, IP

timestamps = []
string_bin = ""  # Biến toàn cục để lưu chuỗi nhị phân

def icmp_handler(packet):
    global string_bin  # Khai báo string_bin là biến toàn cục
    if packet.haslayer(ICMP) and packet[ICMP].type == 0:  # ICMP Echo Reply
        print("Nhận được 1 gói tin từ", packet[IP].src)
        timestamps.append(packet.time)
        if len(timestamps) > 1:
            temp = timestamps[-1] - timestamps[-2]
            print(f"Khoảng thời gian giữa hai gói ICMP: {temp:.6f} giây")
            if temp < 2:
                string_bin += "1"
            else:
                string_bin += "0"
            if temp > 5:
                print("Đã nhan xong gói tin")
                print(string_bin[:(len(string_bin)-1)])  # In chuỗi nhị phân

print("Đang lắng nghe các gói ICMP đến...")
sniff(filter="icmp", prn=icmp_handler, store=0)  # Chạy vô hạn


