from scapy.all import sniff, ICMP, IP 

timestamps = []
def icmp_handler(packet):
    if packet.haslayer(ICMP) and packet[ICMP].type == 0:  # ICMP Echo Reply
        print("nhận được 1 gói tin từ " , packet[IP].src)
        timestamps.append(packet.time)
        if len(timestamps) > 1:
            temp = timestamps[-1] - timestamps[-2]
            print(f"Khoảng thời gian giữa hai gói ICMP: {temp:.6f} giây")


print("Đang lắng nghe các gói ICMP đến...")
sniff(filter="icmp", prn=icmp_handler, store=0)  # Chạy vô hạn


