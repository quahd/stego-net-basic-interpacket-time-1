import os
import sys

binary_string1 = "".join(sys.argv[1:])

def binary_list_to_ascii():

    # binary_string1 = ''.join(str(bit) for bit in binary_string)
    chars = [binary_string1[i:i+8] for i in range(0, len(binary_string1), 8)]
    ascii_string = ''.join(chr(int(char, 2)) for char in chars)
    return ascii_string

print(binary_list_to_ascii())

