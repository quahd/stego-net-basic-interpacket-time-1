import time
from scapy.all import IP, ICMP, send
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('ss', type=str)
parser.add_argument('ip', type=str)
args = parser.parse_args()

def string_to_binary(input_string):
    return ' '.join(format(ord(char), '08b') for char in input_string)

def send_packet_with_ttl(destination_ip, binary_string):

    packet = IP(dst=destination_ip) / ICMP() 
#    send(packet, verbose=0) 


    for i in range(0, len(binary_string)):
        if binary_string[i] == '1':
            packet = IP(dst=destination_ip) / ICMP() 
            send(packet, verbose=0)
        else:
            time.sleep(2000 / 1000.0)
            packet = IP(dst=destination_ip) / ICMP() 
            send(packet, verbose=0)
    time.sleep(5000 / 1000.0)
    send(packet, verbose=0)


if __name__ == "__main__":

    stringrcv = args.ss
    stringbin = string_to_binary(stringrcv)
    binary_string = ''.join(stringbin.split(" "))

    send_packet_with_ttl(args.ip, binary_string)

